﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MockingCCE
{
    public interface ITestObject
    {
        int GetResult();
        int CalculateResult(int x, int y);
    }

    public interface ISomeInterface
    {
        List<int> SomeData();
    }

    public interface IFoo
    {
        void DoSomething();
    }

    public class MathClass
    {
        private readonly ITestObject testObject;

        public MathClass(ITestObject testObject)
        {
            this.testObject = testObject;
        }

        public int CalculateResult(int firstNumber, int secondNumber)
        {
            int result = 0;
            if (firstNumber < 10)
                result = firstNumber + secondNumber;
            else
                result = firstNumber * secondNumber;
            return result;
        }
    }

    public class SomeClass
    {
        public List<int> SomeData()
        {
            List<int> numbers = new List<int>()
            {
                10,
                20,
                30
            };
            return numbers;
        }
    }

    public class Foo
    {
        public void DoSomething()
        {
            throw new InvalidOperationException();
        }
    }
}
