﻿using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MockingCCE.Tests
{
    [TestFixture]
    public class MathTests
    {
        [Test]
        public void CalculateResultTest()
        {
            Mock<ITestObject> test = new Mock<ITestObject>();
            test.Setup(m => m.CalculateResult(It.Is<int>(i => i < 10), It.IsAny<int>()))
                .Returns((int x, int y) => x + y);
            test.Setup(m => m.CalculateResult(It.Is<int>(i => i >= 10), It.IsAny<int>()))
                .Returns((int x, int y) => x * y);

            ITestObject mathTest = test.Object;
            int addition = mathTest.CalculateResult(5, 8);
            Assert.That(addition, Is.EqualTo(13));
            int multiplication = mathTest.CalculateResult(10, 20);
            Assert.That(multiplication, Is.EqualTo(200));
        }

        [Test]
        public void CollectionTest()
        {
            Mock<ISomeInterface> mockSomeInterface = new Mock<ISomeInterface>();
            mockSomeInterface.Setup(si => si.SomeData()).Returns(() => new List<int> { 10, 20, 30 });

            ISomeInterface someInterface = mockSomeInterface.Object;
            List<int> numbers = someInterface.SomeData();
            CollectionAssert.AreEquivalent(new List<int> { 10, 20, 30 }, numbers);
        }
        [Test]
        public void ExceptionTest()
        {
            Mock<IFoo> mock = new Mock<IFoo>();
            mock.Setup(fo => fo.DoSomething()).Throws(new InvalidOperationException());
            IFoo foo = mock.Object;
            Assert.Throws<InvalidOperationException>(() => foo.DoSomething());
        }
    }
}
