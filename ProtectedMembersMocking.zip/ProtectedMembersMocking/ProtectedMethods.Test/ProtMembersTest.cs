﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq.Protected;
using Moq;

namespace ProtectedMethods.Test
{
    [TestFixture]
    public class ProtMembersTest
    {
        [Test]
        public void Test1()
        {
            var mock = new Mock<ProtMembers>() { CallBase= true };
            mock.Protected()
                .Setup("ProtectedMethod1")
                .Verifiable();
            mock.Object.CallProtectedMethod1();
            mock.Verify();
        }
        [Test]
        public void Test2()
        {
            var mock = new Mock<ProtMembers>() { CallBase = true };
            mock.Protected()
                .Setup<int>("ProtectedMethod2")
                .Returns(1090)
                .Verifiable();
            int result = mock.Object.CallProtectedMethod2();
            mock.Verify();
            Assert.AreEqual(1090, result);
        }
        [Test]
        public void Test3()
        {
            var mock = new Mock<ProtMembers>() { CallBase = true };
            mock.Protected()
                .Setup<string>("GetFullName",new object[] {"Sachin","Tendulkar"})
                .Returns("Sachin Tendulkar")
                .Verifiable();
            string fullName = mock.Object.CallGetFullName("Sachin", "Tendulkar");
            mock.Verify();
            Assert.AreEqual("Sachin Tendulkar", fullName);
        }
    }
}
