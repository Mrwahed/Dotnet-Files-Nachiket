﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProtectedMethods
{
    public class ProtMembers
    {
        protected virtual void ProtectedMethod1()
        {
            int param = 1000;
            System.Diagnostics.Trace.Write(param);
        }
        public virtual void CallProtectedMethod1()
        {
            ProtectedMethod1();
        }
        protected virtual int ProtectedMethod2()
        {
            int param = 1090;
            return param;
        }
        public virtual int CallProtectedMethod2()
        {
            int result = ProtectedMethod2();
            return result;
        }
        protected virtual string GetFullName(string firstname,string lastName)
        {
            string fullName = string.Concat(firstname, " ", lastName);
            return fullName;
        }
        public virtual string CallGetFullName(string firstname,string lastName) 
        {
            string fullName = GetFullName(firstname, lastName);
            return fullName;
        }
    }
}
