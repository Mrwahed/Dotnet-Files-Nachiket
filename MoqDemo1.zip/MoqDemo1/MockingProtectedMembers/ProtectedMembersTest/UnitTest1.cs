using NUnit.Framework;
using Moq;
using Moq.Protected;
using ProtectedMembers;

namespace ProtectedMembersTest
{
    public class Tests
    {
        [Test]
        public void Test1()
        {
            var mock = new Mock<ProtMembers>() { CallBase = true };
            mock.Protected()
                .Setup("ProtectedMethod1")
                .Verifiable();
            mock.Object.CallProtectedMethod1();
            mock.Verify();
        }

        [Test]
        public void Test2()
        {
            var mock = new Mock<ProtMembers>() { CallBase = true };
            mock.Protected()
                .Setup<int>("ProtectedMethod2")
                .Returns(1090)
                .Verifiable();

            int responseValue = mock.Object.CallProtectedMethod2();
            mock.Verify();
            Assert.AreEqual(1090, responseValue);
        }

        [Test]
        public void Test3()
        {
            var mock = new Mock<ProtMembers>() { CallBase = true };
            mock.Protected()
                .Setup<string>("GetName", new object[] { "Pusarla", "Sindhu" })
                .Returns("Pusarla Sindhu")
                .Verifiable();
            string name = mock.Object.CallGetName("Pusarla", "Sindhu");
            mock.Verify();
            Assert.AreEqual("Pusarla Sindhu", name);
        }
    }
}