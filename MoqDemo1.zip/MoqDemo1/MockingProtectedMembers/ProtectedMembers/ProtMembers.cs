﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProtectedMembers
{
    public class ProtMembers
    {
        protected virtual void ProtectedMethod1()
        {
            int param = 1000;
            System.Diagnostics.Trace.Write(param);
        }

        public virtual void CallProtectedMethod1()
        {
            ProtectedMethod1();
        }

        protected virtual int ProtectedMethod2()
        {
            int param = 1090;
            return param;
        }

        public virtual int CallProtectedMethod2()
        {
            int responseValue = ProtectedMethod2();
            return responseValue;
        }

        protected virtual string GetName(string firstName, string lastName)
        {
            string fullName = string.Concat(firstName, " ", lastName);
            return fullName;
        }

        public virtual string CallGetName(string firstName, string lastName)
        {
            string fullName = GetName(firstName, lastName);
            return fullName;
        }
    }
}
