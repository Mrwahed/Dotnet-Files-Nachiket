﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingSystem
{
    public class BankAccount
    {
        public int Balance { get; set; }
        private const int MinimumSalary = 65000;
        private const int CreditScore = 300;
        private const int MinimumAge = 19;

        public readonly ILogger logger;
        private IIdentityVerifier identityVerifier;
        private ICreditScorer creditScorer;
        public BankAccount(ILogger logger)
        {
            this.logger = logger;
        }

        public BankAccount(IIdentityVerifier identityVerifier, ICreditScorer creditScorer)
        {
            this.identityVerifier= identityVerifier;
            this.creditScorer= creditScorer;
        }
        public void Deposit(int amount)
        {
            logger.Write($"User has deposited {amount}");
            Balance += amount;
        }
        public void Withdraw(int amount)
        {
            logger.Write($"User has withdrawn {amount}");
            Balance-= amount;
        }
        public bool ProcessLoan(string name,string address,int age,int salary)
        {
            if(age<MinimumAge) 
                return false;
            if (salary < MinimumSalary)
                return false;
            var isValidIdentity = identityVerifier.Validate(name, age, address);
            if(!isValidIdentity) 
                return false;
            if (creditScorer.Score < CreditScore)
                return false;
            return true;
        }
    }
}
