﻿using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingSystem.Tests
{
    [TestFixture]
    public class BankAccountTests
    {
        [Test]
        public void ShouldDepositAmount()
        {
            Mock<ILogger> logger = new Mock<ILogger>();
            BankAccount account = new BankAccount(logger.Object) { Balance= 10000 };
            account.Deposit(5000);
            Assert.That(account.Balance, Is.EqualTo(15000));
        }
        [Test]
        public void ShouldWithdrawAmount()
        {
            Mock<ILogger> logger = new Mock<ILogger>();
            BankAccount account = new BankAccount(logger.Object) { Balance = 10000 };
            account.Withdraw(5000);
            Assert.That(account.Balance, Is.EqualTo(5000));
        }
        [Test]
        public void ShouldDeclineLoan()
        {
            Mock<IIdentityVerifier> identityVerifier= new Mock<IIdentityVerifier>();
            Mock<ICreditScorer> creditScorer= new Mock<ICreditScorer>();
            BankAccount account = new BankAccount
                (identityVerifier.Object,creditScorer.Object);
            var result = account.ProcessLoan("Amol", "Mumbai", 33, 61000);
            Assert.That(result, Is.False);
        }
        [Test]
        public void ShouldAcceptLoan()
        {
            Mock<IIdentityVerifier> identityVerifier = new Mock<IIdentityVerifier>();
            Mock<ICreditScorer> creditScorer = new Mock<ICreditScorer>();
            BankAccount account = new BankAccount(identityVerifier.Object, creditScorer.Object);
            identityVerifier.Setup(x => x.Validate(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<string>())).Returns(true);
            creditScorer.Setup(x => x.Score).Returns(300);
            var result = account.ProcessLoan("Sanjana", "Bengaluru", 35, 65000);
            Assert.That(result, Is.True);

        }
    }
}
