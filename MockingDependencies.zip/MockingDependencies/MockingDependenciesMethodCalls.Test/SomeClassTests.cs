﻿using DependenciesMethodCalls;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MockingDependenciesMethodCalls.Test
{
    [TestFixture]
    public class SomeClassTests
    {
        [Test]
        public void MyMethodTest()
        {
            string name = "test";
            Mock<SomeClass> someClassMock = new Mock<SomeClass>();
            someClassMock.Setup(mock => mock.DoSomething(name));
            MyClass myClass = new MyClass(someClassMock.Object);
            //myClass.MyMethod(name);
            //someClassMock.Verify(mock=>mock.DoSomething(name),Times.Once);
            myClass.MyMethod(name);
            myClass.MyMethod(name);
            myClass.MyMethod(name);
            someClassMock.Verify(mock => mock.DoSomething(name), Times.Exactly(3));
            //someClassMock.VerifyAll();
        }
    }
}
