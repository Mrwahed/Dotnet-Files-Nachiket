﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DependenciesMethodCalls
{
    public class SomeClass
    {
        public string Something { get; set; }
        public virtual void DoSomething(string name)
        {
            Something = "Hello";
            System.Diagnostics.Trace.Write(name);
        }

        public virtual void DoSomething2(SomeClass someClass)
        {
            someClass.Something = "Hello";
            System.Diagnostics.Trace.Write(someClass.Something);
        }
    }

    public class MyClass
    {
        SomeClass some;
        public MyClass(SomeClass some) 
        {
            this.some = some;
        }
        public virtual void MyMethod(string method)
        {
            some.DoSomething(method);
        }

        public virtual void MyMethod2(SomeClass someClass)
        {
            some.DoSomething2(someClass);
        }
    }
}
